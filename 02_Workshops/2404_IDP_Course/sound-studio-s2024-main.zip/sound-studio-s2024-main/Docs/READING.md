[ICMC Proceedings 2022](https://www.fulcrum.org/epubs/8910jx22c?locale=en#page=1)

Bill Orcutt, [I dropped my phone the screen cracked](https://github.com/billorcutt/i_dropped_my_phone_the_screen_cracked)

Nathan Ho, [Posts about DSP](https://nathan.ho.name/categories/dsp/)
